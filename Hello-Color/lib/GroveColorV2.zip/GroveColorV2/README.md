## Grove - I2C Color Sensor Library for Wio LTE M1/NB1(BG96)

 Grove - I2C Color Sensor V2 Library is modified from Grove_I2C_Color_Sensor_TCS3472.

 https://github.com/Seeed-Studio/Grove_I2C_Color_Sensor_TCS3472
 